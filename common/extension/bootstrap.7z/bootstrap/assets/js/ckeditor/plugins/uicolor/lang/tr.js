﻿/*
 Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","tr",{title:"UI Renk Seçicisi",preview:"Canlı önizleme",config:"Bu dizeyi config.js dosyasının içine yapıştırın",predefined:"Önceden tanımlanmış renk kümeleri"});